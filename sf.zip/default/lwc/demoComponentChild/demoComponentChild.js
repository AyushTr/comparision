import { LightningElement,api } from 'lwc';

export default class DemoComponentChild extends LightningElement {
    @api sno;
    @api id;
    @api name;
    @api price;
    @api payoff;
    @api market;
    @api remainingpayment;
    @api image;
    @api cimage;

}