import { LightningElement,api } from 'lwc';

export default class HelloChild extends LightningElement {
    @api item;

}