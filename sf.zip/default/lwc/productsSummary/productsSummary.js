import { LightningElement, wire } from 'lwc';
import getTotalAmount from '@salesforce/apex/GetProducts.getTotalAmount';
import { subscribe, MessageContext } from "lightning/messageService";
import CART_CHANNEL from "@salesforce/messageChannel/CartChannel__c";
import { refreshApex } from '@salesforce/apex';

export default class ProductsSummary extends LightningElement {
    @wire(getTotalAmount) amount;
     @wire(MessageContext)
     messageContext;
        subscribeToMessageChannel() {
      //  alert("subscribe");
        if (!this.subscription) {
            this.subscription = subscribe(
                this.messageContext,
                CART_CHANNEL,
                (message) => this.handleMessage(message)
            );
           
        }
    }

     handleMessage(message) {
        this.selectedMenuOption = message.menuSelected;
        if(this.selectedMenuOption !== null)
        {
          refreshApex(this.amount);  
        }
        else{
         alert("Not refresh");
        }
       
    }

     connectedCallback() {
        refreshApex(this.amount); 
        this.subscribeToMessageChannel();
    }
}