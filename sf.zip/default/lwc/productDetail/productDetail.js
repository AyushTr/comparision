import { LightningElement } from 'lwc';

export default class ProductDetail extends LightningElement {}