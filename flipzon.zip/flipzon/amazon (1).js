import { LightningElement , track , api ,wire} from 'lwc';
import getmobile from '@salesforce/apex/controlmobile.getmobile';
import getmobileList from '@salesforce/apex/controlmobile.getmobileList';
import Addcart from '@salesforce/apex/controlmobile.Addcart';
import getList from  '@salesforce/apex/controlmobile.getList';
import total from  '@salesforce/apex/controlmobile.total';
import managedelete from  '@salesforce/apex/controlmobile.managedelete';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { deleteRecord } from 'lightning/uiRecordApi';

export default class Amazon extends LightningElement {

   
   @track list;
   @track list1;
   @track flagm = false;
   @track flagw = true;

   handlehome(){

       getmobile().then(result=>
        {this.list=result;})
        .catch(error=>{this.list1=error;  })
         this.flagm=true;
         this.flagw= false;
         this.cart = false;
         this.show = false;
         this.flags = false;
         
   
     }
  
     searchValue = '';
     @track mobileRecord
     @track e1= false;
     @track flags= false;


     searchKeyword(event) {
        this.searchValue = event.target.value;
        this.flags= true;
        this.flagm = false;
        if (this.searchValue !== '') {
            getmobileList({
                    searchKey: this.searchValue
                })
                .then(result => {
                    
                    this.mobileRecord = result;
                })
                .catch(error => {
                           this.error = error;
                           this.e1 = true;
                    });
                  
        }
         
      


    }
       
    @track show = false;
    @track name1;
    @track price;
    @track rev;
    @track img;
    @track ram;
    @track st;
    @track del;
    @track a;
    @track b;
    @track c;


    viewdetails(event)
    {
        this.show = true;
        this.flagm = false;
        this.flags = false;
        this.flagw = false;
        this.cart = false;
        this.flags = false;
        this.name1 = event.currentTarget.dataset.key1;
        this.img = event.currentTarget.dataset.key;
        this.rev = event.currentTarget.dataset.key2;
        this.ram = event.currentTarget.dataset.key4;
        this.st = event.currentTarget.dataset.key5;
        this.del = event.currentTarget.dataset.key6;
        this.price = event.currentTarget.dataset.key3;
        this.c = event.currentTarget.dataset.key7;

    }

    handlecart()
    { 
    


        Addcart({url :this.img , name2 : this.name1 ,  price : this.price , prodId : this.c}).then(result=>
            {this.a=result;}).
            then( () => {
                refreshApex(this.amt); })
            .catch(error=>{this.b=error;  })
        alert("Sucess");

        


    }

   @track q; 
   @track cart = false;
  handlequantity()
  {
      getList().then(result=> {this.q = result;}).
      then( () => {
          refreshApex(this.amt); })
      .catch(error =>{this.error = error;})
      this.cart = true;
      this.flagm = false;
      this.flagw = false;
      this.show = false;
      this.flags = false;
  } 
  
  @track amt;
  
  @wire(total)
   amt;
  
  @track delname;
  @track m; 
  @api
 
 handledelete(event)
 {
        this.delname = event.currentTarget.dataset.key21;
        console.log(this.delname);
        managedelete({ pname : this.delname }).
        then(result=> {this.m = result;}).
        catch(error=>{this.b=error;  })
        alert("Success");
        getList().then(result=> {this.q = result;}).
        then( () => {
            refreshApex(this.amt); })
      .catch(error =>{this.error = error;})
      this.cart = true;
      this.flagm = false;
      this.flagw = false;
      this.show = false;
      this.flags = false;

 }
  






}