import { LightningElement, wire,track } from 'lwc';
import getVehicleData from'@salesforce/apex/Getvehicle.getVehicleData';
import { subscribe, MessageContext } from "lightning/messageService";
import DEMO_CHANNEL from "@salesforce/messageChannel/DemoChannel__c";

export default class DetailComponent extends LightningElement {
    @track grounded=true;
    @track passed=false;
    @track purchased=false;

    @wire(getVehicleData)
    vehicles;
    selectedMenuOption;
    @wire(MessageContext)
    messageContext;

    subscribeToMessageChannel() {
        alert("subscribe");
        if (!this.subscription) {
            this.subscription = subscribe(
                this.messageContext,
                DEMO_CHANNEL,
                (message) => this.handleMessage(message)
            );
           
        }
    }

    handleMessage(message) {
        this.selectedMenuOption = message.menuSelected;
        console.log(this.selectedMenuOption);
        if(this.selectedMenuOption=='grounded')
        {
            this.grounded=true;
            this.passed=false;
            this.purchased=false; 
        }
        if(this.selectedMenuOption=='passed')
        {
            this.grounded=false;
            this.passed=true;
            this.purchased=false; 
        }
        if(this.selectedMenuOption=='purchased')
        {
            this.grounded=false;
            this.passed=false;
            this.purchased=true;
        }
    }

    connectedCallback() {
        this.subscribeToMessageChannel();
    }

}