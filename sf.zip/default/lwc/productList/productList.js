import { LightningElement, wire,track} from 'lwc';
import productsData from '@salesforce/apex/GetProducts.productsData';
import productsSearchData from '@salesforce/apex/GetProducts.productsSearchData';

export default class ProductList extends LightningElement {
resultdata;    
@track search=false;
@wire(productsData)
productlist({error,data})
{
    if(this.search == false)
    {
        this.resultdata =data;
    }
}
    strOutput;
    resultdata;
    searchValue(event)
    {   this.search =true;
        this.strOutput=event.detail;
        productsSearchData({searchKey : this.strOutput})
        .then((result)=>{
            if(this.search==true)
            {
                this.resultdata=result;
            }
        })
    }


   
}