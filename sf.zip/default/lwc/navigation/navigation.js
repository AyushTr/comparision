import { LightningElement, track, wire } from 'lwc';
import { publish, MessageContext } from "lightning/messageService";
import DEMO_CHANNEL from "@salesforce/messageChannel/DemoChannel__c";

export default class Navigation extends LightningElement {
    @track selectedItem='grounded';
    @wire(MessageContext)
    messageContext;

    // Respond to UI event by publishing message
    handleSelect(event) {
        this.selectedItem=event.detail.name;
        const payload = { menuSelected: this.selectedItem };
        publish(this.messageContext, DEMO_CHANNEL, payload);
    }
}