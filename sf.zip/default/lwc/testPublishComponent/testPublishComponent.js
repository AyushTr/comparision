import { LightningElement, wire } from 'lwc';
import { publish, MessageContext } from "lightning/messageService";
import TEST_CHANNEL from "@salesforce/messageChannel/DemoChannel__c";

export default class TestPublishComponent extends LightningElement {

    @wire(MessageContext)
    messageContext;

    handleClick() {
        const messaage = {
          recordId: "001xx000003NGSFAA4",
          name: "Burlington Textiles of America"
        };

        publish(this.messageContext, TEST_CHANNEL, messaage);

}
}