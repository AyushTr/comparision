import { LightningElement, track } from "lwc";
import getVehicleData from'@salesforce/apex/Getvehicle.getVehicleData';


export default class DemoComponent extends LightningElement{
    @track accounts;
    @track error;

    handleLoad() {
        getVehicleData()
            .then(result => {
                this.accounts = result;
                console.log(this.accounts);
            })
            .catch(error => {
                this.error = error;
            });
    }

}