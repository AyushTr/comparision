import { LightningElement} from 'lwc';

export default class HelloParent extends LightningElement {
    strInput;
    handleChange( event ) {
        this.strInput = event.target.value;

    }
   
}