import { LightningElement } from 'lwc';

export default class SearchProduct extends LightningElement {
    strInput; 

    handleAction(event){
     this.strInput=event.target.value;  
     this.dispatchEvent( new CustomEvent( 'pass', {
        detail: this.strInput
    } ) ); 
    }

    // handleSearch()
    // {
    //     this.dispatchEvent( new CustomEvent( 'pass', {
    //         detail: this.strInput
    //     } ) );
    // }
}