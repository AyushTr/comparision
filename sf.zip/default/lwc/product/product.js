import { LightningElement,track,wire, api } from 'lwc';
import removeFromCart from '@salesforce/apex/GetProducts.removeFromCart';
import addProductToCart from '@salesforce/apex/GetProducts.addProductToCart';
import getCartProduct from '@salesforce/apex/GetProducts.getCartProduct'
import { publish, MessageContext } from "lightning/messageService";
import CART_CHANNEL from "@salesforce/messageChannel/CartChannel__c";
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Product extends LightningElement {
    _title = 'Add to Cart';
    message = 'Sample Message';
    variant = 'success';

    @track selectedItem;
    @wire(MessageContext)
    messageContext;

     @track wiredAccountList = [];
    @api id;
    @api name;
    @api price;
    @api cart;
    @api quantity;
    @api image;
    @api description;
    @api details;

    productid;

    @track openModal = false;
    product;
    productid='';
    prodId='';
    error;
    SucessMessage;

    showModal() {
        this.openModal = true;
    }
    closeModal() {
        this.openModal = false;
    }

    @wire(getCartProduct)
    cartList(result){
         this.wiredAccountList = result;
         
    }

    addtocart(event)
    {
        this.productid=event.target.id;
            addProductToCart({productid: this.productid})
            .then((message) =>{
                this.SucessMessage = message; 
               // refreshApex(this.wiredAccountList);
            })
            .catch((error) => {
                this.error = error;
                console.log(this.error);
               this.product = undefined;
            });
            console.log(this.SucessMessage);
            this.message='Item add to cart Successfully';
             const evt = new ShowToastEvent({
            title: this._title,
            message: this.message,
            variant: this.variant,
        });
        this.dispatchEvent(evt);
    
       // alert(this.productid);
        this.openModal = false;
        const payload = { menuSelected: this.productid };
      publish(this.messageContext, CART_CHANNEL, payload);
        
    }

    removeCartProduct(event){
        this.prodId=event.target.id;
        removeFromCart({productid: this.prodId})
        .then((message)=>{
            this.SucessMessage= message;
        });
           this._title ='Removed from Cart';
          this.message='Item Removed from the Cart';
          this.variant='warning';
             const evt = new ShowToastEvent({
            title: this._title,
            message: this.message,
            variant: this.variant,
        });
        this.dispatchEvent(evt);
      //  alert(this.SucessMessage);
       const payload = { menuSelected: this.prodId };
      publish(this.messageContext, CART_CHANNEL, payload);

    }
}