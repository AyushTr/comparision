import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
export default class ProductNavigation extends NavigationMixin(LightningElement) {
     navigateToCart() {
        // Navigate to a specific CustomTab.
        this[NavigationMixin.Navigate]({
            type: 'standard__navItemPage',
            attributes: {
                apiName: 'Cart'
            }
        });
    }

    navigateToHome(){
        this[NavigationMixin.Navigate]({
            type: 'standard__navItemPage',
            attributes: {
                apiName: 'Search_Product'
            }
        });
    }
}