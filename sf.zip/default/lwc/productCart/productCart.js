import { LightningElement, track, wire} from 'lwc';
import getCartProduct from '@salesforce/apex/GetProducts.getCartProduct';
import { subscribe, MessageContext } from "lightning/messageService";
import CART_CHANNEL from "@salesforce/messageChannel/CartChannel__c";
import { refreshApex } from '@salesforce/apex';

export default class ProductCart extends LightningElement {
    @track iscart=true;
    @track dataExist=false;
    @track cartProducts =[];
    @track nodata=false;
    @wire(MessageContext)
    messageContext;

    contacts;
    error;
    @wire(getCartProduct) cartProducts;
    @wire(getCartProduct)
    wiredContacts(result) {
       this.cartProducts =result;
        if (result.data) {
            this.contacts = result.data;
            console.log(this.contacts.length);
            if(this.contacts.length==0)
            {
            this.nodata=true;
            }
            else if(this.contacts.length>0)
            {
                this.dataExist=true;
            }
            this.error = undefined;
        } else if (result.error) {
            this.error = error;
            this.contacts = undefined;
        }
    }


     subscribeToMessageChannel() {
      //  alert("subscribe");
        if (!this.subscription) {
            this.subscription = subscribe(
                this.messageContext,
                CART_CHANNEL,
                (message) => this.handleMessage(message)
            );
           
        }
    }

     handleMessage(message) {
        this.selectedMenuOption = message.menuSelected;
       // alert(this.selectedMenuOption);
        if(this.selectedMenuOption !== null)
        {
          refreshApex(this.cartProducts);  
        }
        else{
         alert("Not refresh");
        }
       
    }

     connectedCallback() {
        refreshApex(this.cartProducts);
        this.subscribeToMessageChannel();
    }
    
}