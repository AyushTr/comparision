import { LightningElement } from 'lwc';
export default class HelloComponent extends LightningElement {
//   greeting = 'World';
//   changeHandler(event) {
//     this.greeting = event.target.value;
//   }
value = '';
salse=false;
force=false;

get options() {
    return [
        { label: 'Sales', value: 'sales' },
        { label: 'Force', value: 'force' },
    ];
}

action(event){
    this.value = event.target.value;
    if(this.value=='sales')
    {
         this.salse=true;
         this.force=false;
    }
    else if(this.value=='force')
    {
        this.force=true;
        this.salse=false;
    }
    console.log(this.value);
}

contacts = [
    {
        Id: 1,
        Name: 'Avnish Saini',
        Title: 'VP of Engineering',
    },
    {
        Id: 2,
        Name: 'Michael Jones',
        Title: 'VP of Sales',
    },
    {
        Id: 3,
        Name: 'Jennifer Wu',
        Title: 'CEO',
    },
    {
        Id: 4,
        Name: 'User ',
        Title: 'Test User',
    },
];



}