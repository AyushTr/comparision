import { LightningElement, wire } from 'lwc';
import getContactList from '@salesforce/apex/GetAccount.getContactList'

export default class TestComponent extends LightningElement {
    @wire(getContactList) Contacts;

    action()
    {
        console.log(this.Contacts.data);
    }
}